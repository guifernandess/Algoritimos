
import java.util.Scanner;

public class Erxercicio1 {

    public static void main(String[] args) {
        int n, b;
        Scanner console = new Scanner(System.in);
        System.out.print("Digite um número: ");
        n = console.nextInt();
        if (n > 100) {b = n + 150;
       
     System.out.printf("O Reseultado é %d", b);
    }
else {System.out.println("O Número é menor que 100");
    }
    }}

